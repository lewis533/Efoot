# eFootball 2026 — Mobile Web Game

A fully playable eFootball 2026 clone built as a PWA (Progressive Web App). Deploy to GitHub Pages and play on any mobile browser.

## 📁 File Structure

```
efootball/
├── index.html              ← Main app shell (all screens)
├── manifest.json           ← PWA manifest
├── service-worker.js       ← Offline support
├── css/
│   ├── main.css            ← Variables, splash, topbar, nav, animations
│   ├── screens.css         ← Home, match-type, modals
│   ├── match.css           ← Match HUD, field, controls
│   ├── squad.css           ← Squad & store screen styles
│   ├── store.css           ← Store overrides
│   └── components.css      ← Shared micro-components
├── js/
│   ├── app.js              ← Core router, state, utilities
│   ├── home.js             ← Home screen controller
│   ├── match.js            ← Full match engine (AI, physics, goals)
│   ├── squad.js            ← Squad builder & player modal
│   └── store.js            ← Store, pack opening, GP shop
├── data/
│   ├── players.js          ← Player database (squad + pack pool)
│   └── events.js           ← Events, match types, scout packs
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

## 🚀 Deploy to GitHub Pages (Step by Step)

### Step 1 — Create GitHub repo
1. Go to [github.com](https://github.com) → click **New repository**
2. Name it: `efootball-2026`
3. Set to **Public**
4. Click **Create repository**

### Step 2 — Upload all files
**Option A — GitHub web upload (easiest):**
1. In your new repo, click **Add file → Upload files**
2. Drag ALL files and folders into the upload area
   - `index.html`
   - `manifest.json`
   - `service-worker.js`
   - The entire `css/` folder
   - The entire `js/` folder
   - The entire `data/` folder
   - The entire `icons/` folder
3. Click **Commit changes**

**Option B — Git CLI:**
```bash
git init
git add .
git commit -m "eFootball 2026 - initial"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/efootball-2026.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages
1. Go to your repo → **Settings** tab
2. Scroll to **Pages** (left sidebar)
3. Under **Source** → select **main** branch → folder **/ (root)**
4. Click **Save**
5. Wait ~60 seconds, then visit:
   `https://YOUR_USERNAME.github.io/efootball-2026/`

## 🎮 Gameplay

| Screen | Description |
|--------|-------------|
| **Home** | Main hub — events, objectives, recent results |
| **Match** | Live 11v11 match with D-pad, pass, shoot, tactics |
| **Squad** | 4-3-3 formation view + player stat cards |
| **Store** | Scout packs, GP shop, pack opening animation |

### Match Controls
- **D-pad** — Move selected player + ball
- **PASS** — Short pass to nearby teammate
- **SHOT / SHOOT** — Attempt on goal (chance based on position + stats)
- **THRU** — Through ball to striker
- **SKILL** — Skill move
- **SPRINT** — Hold for speed boost (drains stamina)
- **Tactics** — Normal / Attack / Defend / Press / Counter

### Pack Opening
1. Go to **Store → Scouts**
2. Tap any scout pack
3. Tap the 📦 to reveal your player
4. Players range from Epic → Legendary tiers

## 📱 Install as App (PWA)

**Android (Chrome):**
1. Open the GitHub Pages URL in Chrome
2. Tap the **⋮ menu → Add to Home Screen**
3. Tap **Add** — icon appears on your home screen

**iPhone (Safari):**
1. Open the URL in Safari
2. Tap **Share → Add to Home Screen**

## 🛠 Customization

- **Add players:** Edit `data/players.js` → `squad` array
- **Add events:** Edit `data/events.js` → `featured` array
- **Change team:** Edit `match.js` → `HOME_TEAM` object
- **Add formations:** Edit `squad.js` → `SLOTS` array
- **Colors:** Edit `css/main.css` → `:root` variables

## ⚡ Tech Stack
- Vanilla HTML5 / CSS3 / JavaScript (no frameworks)
- Canvas API for pitch rendering
- CSS animations for goal overlay & splash
- PWA with Service Worker for offline play
- ~130KB total (no dependencies)

/* js/home.js — Home screen controller */
'use strict';

const Home = (() => {
  let _built = false;

  function init() {
    if (_built) return;
    _built = true;
    _buildEvents();
    _buildResults();
  }

  function _buildEvents() {
    const container = document.getElementById('eventsScroll');
    if (!container) return;
    container.innerHTML = EventsDB.featured.map(ev => `
      <div class="ev-card" onclick="App.showToast('${ev.title}: Earn ${ev.reward}!')">
        <div class="ev-img" style="background:${ev.bg};">
          <span style="font-size:38px;filter:drop-shadow(0 4px 8px rgba(0,0,0,.4));">${ev.emoji}</span>
          <div class="ev-timer">⏱ ${ev.timer}</div>
        </div>
        <div class="ev-info">
          <div class="ev-title">${ev.title}</div>
          <div class="ev-sub">${ev.sub}</div>
        </div>
      </div>
    `).join('');
  }

  function _buildResults() {
    const container = document.getElementById('recentResults');
    if (!container) return;
    container.innerHTML = EventsDB.recentResults.map(r => `
      <div class="result-row">
        <div class="res-dot ${r.result}"></div>
        <div class="res-teams">
          ${r.homeTeam} <span class="vs">vs</span> ${r.awayTeam}
        </div>
        <div class="res-score">${r.homeScore} – ${r.awayScore}</div>
        <div class="res-badge ${r.result}">${r.result.toUpperCase()}</div>
      </div>
    `).join('');
  }

  return { init };
})();
